const arrayOfNames = ['jaxx' , 'tiny', 'clay']
const mixedArray = ['anarchy', 99, true]


const makeUpperCase = (arr) => {
    return new Promise((resolve, reject) => {
        try{
            let result = arr.filter(value => typeof value === 'string')
            if(result.length == arr.length){
                let finalResult = arr.map(x => x.toUpperCase())
                resolve(finalResult);
                return;
            }
            else{
                throw new Error(`Not all the items in the array are string`);
            }
        }catch(err) {
            reject(`${err}`);
            return;
          }
    });
  };

  const sortWords = (arr) => {
    return new Promise((resolve, reject) => {
        try{
            let result = arr.filter(value => typeof value === 'string')
            if(result.length == arr.length){
                let finalResult = arr.sort()
                resolve(finalResult);
                return;
            }
            else{
                throw new Error(`Not all the items in the array are string!`);
            }
        }catch(err) {
            reject(`${err}`);
            return;
          }
    });
  };

makeUpperCase(arrayOfNames)
  .then(result => sortWords(result))
  .then(result => console.log(result))
  .catch(error => console.log(error))

makeUpperCase(mixedArray)
  .then(result => sortWords(result))
  .then(result => console.log(result))
  .catch(error => console.log(error))
